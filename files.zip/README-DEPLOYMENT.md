# 🎓 CRM System - Kubernetes Deployment Package

## 📁 Pliki do skopiowania do projektu

### 1️⃣ FRONTEND FILES (katalog `frontend/`)
```bash
# Skopiuj te pliki do katalogu frontend/
cp frontend-Dockerfile frontend/Dockerfile
cp nginx.conf frontend/nginx.conf
cp frontend.env frontend/.env
```

### 2️⃣ KUBERNETES DEPLOYMENTS

#### Backend (`k8s/crm-app/`)
```bash
cp k8s-backend-deployment.yaml k8s/crm-app/deployment.yaml
cp k8s-backend-service.yaml k8s/crm-app/service.yaml
cp k8s-backend-configmap.yaml k8s/crm-app/configmap.yaml
# secret.yaml już istnieje - bez zmian
```

#### Frontend (`k8s/crm-frontend/`)
```bash
cp k8s-frontend-deployment.yaml k8s/crm-frontend/deployment.yaml
cp k8s-frontend-service.yaml k8s/crm-frontend/service.yaml
```

#### Database (`k8s/crm-mysql/`)
```bash
cp k8s-database-deployment.yaml k8s/crm-mysql/deployment.yaml
# service.yaml, secret.yaml, pvc.yaml już istnieją - bez zmian
```

### 3️⃣ SCRIPTS (katalog główny)
```bash
# Nadaj uprawnienia wykonywania
chmod +x build-images.sh
chmod +x deploy-k8s.sh
```

---

## 🚀 QUICK START (3 kroki)

### Opcja A: Automatyczne wdrożenie
```bash
# 1. Zbuduj obrazy Docker
./build-images.sh

# 2. Wdróż do Kubernetes
./deploy-k8s.sh

# 3. Otwórz aplikację
minikube service crm-frontend -n crm
```

### Opcja B: Manualne wdrożenie
```bash
# 1. Zbuduj obrazy
docker build -t crm-app:latest -f Dockerfile .
docker build -t crm-frontend:latest -f frontend/Dockerfile .

# 2. Załaduj do Minikube
minikube image load crm-app:latest
minikube image load crm-frontend:latest

# 3. Deploy
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/crm-mysql/
kubectl apply -f k8s/crm-app/
kubectl apply -f k8s/crm-frontend/

# 4. Sprawdź status
kubectl get all -n crm
```

---

## 📊 Architektura Deploymentu

```
┌─────────────────────────────────────────────┐
│         KUBERNETES CLUSTER (crm ns)         │
├─────────────────────────────────────────────┤
│                                             │
│  ┌──────────────┐         ┌─────────────┐  │
│  │   Frontend   │────────▶│   Backend   │  │
│  │ (Nginx:80)   │  Proxy  │ (Spring:8081│  │
│  │  2 replicas  │         │  2 replicas │  │
│  └──────────────┘         └─────────────┘  │
│        │                         │         │
│        │                         ▼         │
│   NodePort:30080        ┌─────────────┐    │
│                         │   MariaDB   │    │
│                         │  (mysql:3306│    │
│                         │  1 replica  │    │
│                         └─────────────┘    │
│                                │           │
│                         PersistentVolume   │
│                              (5GB)         │
└─────────────────────────────────────────────┘
```

---

## 🔑 Kluczowe zmiany w Kubernetes

### 1. Frontend → Backend Communication
- **Poprzednio**: Frontend próbował łączyć się bezpośrednio na `localhost:8081`
- **Teraz**: Nginx proxy przekierowuje `/api` → `http://crm-app:8080`

### 2. Health Checks
- **Database**: `mariadb-admin ping` + connection test
- **Backend**: `/actuator/health/liveness` + `/actuator/health/readiness` + startup probe
- **Frontend**: `/health` endpoint w nginx

### 3. Resource Management
- **Requests/Limits** ustawione dla wszystkich podów
- **Startup Probe** dla backendu (5 min timeout dla Liquibase)
- **Rolling Update** strategy dla zero-downtime deployments

### 4. High Availability
- Frontend: 2 replicas z session affinity
- Backend: 2 replicas z session affinity
- Database: 1 replica z persistent storage

---

## 🧪 Testowanie po wdrożeniu

### 1. Sprawdź czy wszystko działa:
```bash
# Status wszystkich komponentów
kubectl get all -n crm

# Szczegółowe logi
kubectl logs -n crm -l app=mysql --tail=50
kubectl logs -n crm -l app=crm-app --tail=50
kubectl logs -n crm -l app=crm-frontend --tail=50
```

### 2. Test connectivity:
```bash
# Backend → Database
kubectl exec -n crm -l app=crm-app -- \
  wget -qO- http://localhost:8081/actuator/health

# Frontend → Backend
kubectl exec -n crm -l app=crm-frontend -- \
  wget -qO- http://crm-app:8080/actuator/health
```

### 3. Test w przeglądarce:
1. Otwórz URL (z `minikube service crm-frontend -n crm --url`)
2. Zaloguj się (domyślne konto z Liquibase)
3. Sprawdź CRUD dla Customers, Offers, Tasks

---

## 📸 Screenshots dla dyplomu

### Wymagane screenshoty:
```bash
# 1. Wszystkie pody running
kubectl get pods -n crm

# 2. Wszystkie services
kubectl get svc -n crm

# 3. Complete deployment
kubectl get all -n crm

# 4. Persistent Volume
kubectl get pvc -n crm

# 5. ConfigMaps i Secrets
kubectl get configmaps,secrets -n crm

# 6. Logi z działającego backendu (pokazujące Liquibase migrations)
kubectl logs -n crm -l app=crm-app | grep "Liquibase"

# 7. Dashboard (opcjonalnie)
minikube dashboard
```

### Screenshots z aplikacji:
- Login page
- Dashboard
- Customers list
- Offers list
- Tasks list
- Details page (każdego modułu)

---

## 🔧 Troubleshooting

### Problem: Pody się nie startują
```bash
# Sprawdź status
kubectl describe pod -n crm <POD-NAME>

# Sprawdź logi
kubectl logs -n crm <POD-NAME>
```

### Problem: Backend nie widzi bazy danych
```bash
# Sprawdź czy MySQL pod działa
kubectl get pods -n crm -l app=mysql

# Sprawdź logi MySQL
kubectl logs -n crm -l app=mysql --tail=100

# Sprawdź secret
kubectl get secret mysql-secret -n crm -o yaml | grep MARIADB
```

### Problem: Frontend nie widzi backendu
```bash
# Sprawdź nginx config
kubectl exec -n crm -l app=crm-frontend -- \
  cat /etc/nginx/conf.d/default.conf

# Sprawdź backend service
kubectl get svc crm-app -n crm
```

### Problem: ImagePullBackOff
```bash
# Załaduj obrazy do Minikube ponownie
minikube image load crm-app:latest
minikube image load crm-frontend:latest

# Restartuj deployment
kubectl rollout restart deployment/crm-app -n crm
```

---

## 📚 Dokumentacja dla pracy dyplomowej

### Sekcja: "Containerization & Orchestration"

**Technologies Used:**
- Docker (multi-stage builds)
- Kubernetes 1.28+
- Minikube (local development)
- Nginx (reverse proxy)

**Architecture Decisions:**
1. **Multi-tier deployment**: Separation of concerns (DB/App/Frontend)
2. **High Availability**: Multiple replicas for stateless components
3. **Persistent Storage**: PVC for database data persistence
4. **Health Monitoring**: Comprehensive probes for all components
5. **Resource Management**: CPU/Memory requests and limits
6. **Security**: Secrets for sensitive data, non-root containers

**Benefits:**
- Scalability: Easy horizontal scaling of frontend/backend
- Reliability: Self-healing with automatic pod restarts
- Maintainability: Declarative configuration via YAML
- Portability: Works on any Kubernetes cluster (cloud/on-prem)

---

## ✅ Final Checklist

Przed obroną upewnij się że:

- [ ] Wszystkie pody są w stanie `Running` i `Ready`
- [ ] Aplikacja jest dostępna przez przeglądarkę
- [ ] Login działa
- [ ] CRUD operacje działają dla wszystkich modułów
- [ ] Masz screenshots z `kubectl get all -n crm`
- [ ] Masz screenshots z działającej aplikacji
- [ ] Masz zapisane logi pokazujące Liquibase migrations
- [ ] Rozumiesz architekturę i potrafisz ją wyjaśnić
- [ ] Umiesz uruchomić deployment od zera
- [ ] Wiesz jak zdiagnozować problemy

---

## 🎯 Kluczowe punkty do omówienia na obronie

1. **Dlaczego Kubernetes?**
   - Scalability, High Availability, Self-healing
   - Industry standard dla microservices

2. **Architektura deploymentu:**
   - 3-tier architecture (DB/App/Frontend)
   - Service discovery via DNS
   - Persistent storage dla bazy danych

3. **Security:**
   - Secrets dla haseł
   - Non-root containers
   - Network policies (możliwość rozszerzenia)

4. **Monitoring:**
   - Health checks (liveness/readiness/startup)
   - Actuator endpoints
   - Resource monitoring

5. **CI/CD możliwości:**
   - Automated builds (Docker)
   - Rolling updates
   - Blue-green deployment (możliwość rozszerzenia)

---

Powodzenia! 🎓🚀
