#!/bin/bash

# ===================================================
# SKRYPT DO BUDOWANIA OBRAZÓW DOCKER
# ===================================================

set -e  # Zatrzymaj na pierwszym błędzie

echo "🏗️  Building CRM Docker Images..."
echo ""

# Kolory dla output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funkcja do wyświetlania kroków
step() {
    echo -e "${BLUE}==>${NC} $1"
}

success() {
    echo -e "${GREEN}✓${NC} $1"
}

warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# 1. Backend
step "Building Backend (Spring Boot)..."
docker build -t crm-app:latest -f Dockerfile .
success "Backend image built successfully"
echo ""

# 2. Frontend - sprawdź czy pliki są skopiowane
step "Preparing Frontend files..."

if [ ! -f "frontend/Dockerfile" ]; then
    warning "Copying Dockerfile to frontend directory..."
    cp frontend-Dockerfile frontend/Dockerfile
fi

if [ ! -f "frontend/nginx.conf" ]; then
    warning "Copying nginx.conf to frontend directory..."
    cp nginx.conf frontend/nginx.conf
fi

if [ ! -f "frontend/.env" ]; then
    warning "Copying .env to frontend directory..."
    cp frontend.env frontend/.env
fi

success "Frontend files prepared"
echo ""

step "Building Frontend (React + Nginx)..."
docker build -t crm-frontend:latest -f frontend/Dockerfile .
success "Frontend image built successfully"
echo ""

# 3. Pokaż zbudowane obrazy
step "Docker images:"
docker images | grep -E "REPOSITORY|crm-app|crm-frontend"
echo ""

# 4. Opcjonalnie - załaduj do Minikube
read -p "Załadować obrazy do Minikube? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    step "Loading images to Minikube..."
    minikube image load crm-app:latest
    minikube image load crm-frontend:latest
    success "Images loaded to Minikube"
    echo ""
    
    step "Verifying images in Minikube..."
    minikube image ls | grep crm
fi

echo ""
success "All images built successfully! 🎉"
echo ""
echo "Next steps:"
echo "  1. kubectl apply -f k8s/namespace.yaml"
echo "  2. kubectl apply -f k8s/crm-mysql/"
echo "  3. kubectl apply -f k8s/crm-app/"
echo "  4. kubectl apply -f k8s/crm-frontend/"
echo ""
echo "Or follow the complete guide in KUBERNETES-DEPLOYMENT-GUIDE.md"
