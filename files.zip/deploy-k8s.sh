#!/bin/bash

# ===================================================
# SKRYPT DO WDROŻENIA CRM W KUBERNETES
# ===================================================

set -e

echo "🚀 Deploying CRM to Kubernetes..."
echo ""

# Kolory
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

step() {
    echo -e "${BLUE}==>${NC} $1"
}

success() {
    echo -e "${GREEN}✓${NC} $1"
}

warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

error() {
    echo -e "${RED}✗${NC} $1"
}

# Sprawdź czy kubectl działa
if ! kubectl cluster-info &> /dev/null; then
    error "Kubernetes cluster is not running!"
    echo "Start your cluster first (e.g., 'minikube start')"
    exit 1
fi

success "Kubernetes cluster is running"
echo ""

# 1. Namespace
step "Creating namespace..."
kubectl apply -f k8s/namespace.yaml
success "Namespace created"
echo ""

# 2. Database
step "Deploying Database (MariaDB)..."
kubectl apply -f k8s/crm-mysql/secret.yaml
kubectl apply -f k8s/crm-mysql/pvc.yaml
kubectl apply -f k8s/crm-mysql/deployment.yaml
kubectl apply -f k8s/crm-mysql/service.yaml

echo "  Waiting for database to be ready..."
kubectl wait --for=condition=ready pod -l app=mysql -n crm --timeout=120s
success "Database deployed and ready"
echo ""

# 3. Backend
step "Deploying Backend (Spring Boot)..."
kubectl apply -f k8s/crm-app/configmap.yaml
kubectl apply -f k8s/crm-app/secret.yaml
kubectl apply -f k8s/crm-app/deployment.yaml
kubectl apply -f k8s/crm-app/service.yaml

echo "  Waiting for backend to be ready (this may take 2-3 minutes)..."
kubectl wait --for=condition=ready pod -l app=crm-app -n crm --timeout=300s
success "Backend deployed and ready"
echo ""

# 4. Frontend
step "Deploying Frontend (React + Nginx)..."
kubectl apply -f k8s/crm-frontend/deployment.yaml
kubectl apply -f k8s/crm-frontend/service.yaml

echo "  Waiting for frontend to be ready..."
kubectl wait --for=condition=ready pod -l app=crm-frontend -n crm --timeout=60s
success "Frontend deployed and ready"
echo ""

# 5. Pokaż status
step "Deployment Status:"
kubectl get all -n crm
echo ""

# 6. Pokaż URL
step "Getting application URL..."
echo ""

# Sprawdź czy to Minikube
if command -v minikube &> /dev/null && minikube status &> /dev/null; then
    URL=$(minikube service crm-frontend -n crm --url 2>/dev/null || echo "")
    if [ -n "$URL" ]; then
        success "Application is ready!"
        echo ""
        echo "  Frontend URL: $URL"
        echo ""
        read -p "Open in browser? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            minikube service crm-frontend -n crm
        fi
    fi
else
    # Dla innych klastrów
    NODE_PORT=$(kubectl get svc crm-frontend -n crm -o jsonpath='{.spec.ports[0].nodePort}')
    NODE_IP=$(kubectl get nodes -o jsonpath='{.items[0].status.addresses[?(@.type=="InternalIP")].address}')
    
    success "Application is ready!"
    echo ""
    echo "  Frontend URL: http://$NODE_IP:$NODE_PORT"
    echo ""
fi

echo "Useful commands:"
echo "  kubectl get pods -n crm              # Check pod status"
echo "  kubectl logs -n crm -l app=crm-app   # View backend logs"
echo "  kubectl logs -n crm -l app=crm-frontend # View frontend logs"
echo "  kubectl port-forward -n crm svc/crm-frontend 3000:80 # Local access"
echo ""

success "Deployment completed! 🎉"
