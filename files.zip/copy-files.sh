#!/bin/bash

# ===================================================
# SKRYPT DO SKOPIOWANIA PLIKÓW KUBERNETES DO PROJEKTU
# ===================================================

echo "📦 Copying Kubernetes deployment files..."
echo ""

# Kolory
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

step() {
    echo -e "${BLUE}==>${NC} $1"
}

success() {
    echo -e "${GREEN}✓${NC} $1"
}

# Sprawdź czy jesteśmy w głównym katalogu projektu
if [ ! -f "pom.xml" ]; then
    echo "❌ Error: Please run this script from the project root directory!"
    exit 1
fi

# 1. Frontend files
step "Copying Frontend files..."
cp frontend-Dockerfile frontend/Dockerfile
cp nginx.conf frontend/nginx.conf
cp frontend.env frontend/.env
success "Frontend files copied"

# 2. Backend K8s files
step "Copying Backend Kubernetes files..."
cp k8s-backend-deployment.yaml k8s/crm-app/deployment.yaml
cp k8s-backend-service.yaml k8s/crm-app/service.yaml
cp k8s-backend-configmap.yaml k8s/crm-app/configmap.yaml
success "Backend K8s files copied"

# 3. Frontend K8s files
step "Copying Frontend Kubernetes files..."
cp k8s-frontend-deployment.yaml k8s/crm-frontend/deployment.yaml
cp k8s-frontend-service.yaml k8s/crm-frontend/service.yaml
success "Frontend K8s files copied"

# 4. Database K8s files
step "Copying Database Kubernetes files..."
cp k8s-database-deployment.yaml k8s/crm-mysql/deployment.yaml
success "Database K8s files copied"

# 5. Scripts
step "Setting up deployment scripts..."
chmod +x build-images.sh
chmod +x deploy-k8s.sh
success "Scripts are ready"

echo ""
success "All files copied successfully! 🎉"
echo ""
echo "File structure:"
echo "  frontend/"
echo "    ├── Dockerfile          ✓"
echo "    ├── nginx.conf          ✓"
echo "    └── .env                ✓"
echo ""
echo "  k8s/crm-app/"
echo "    ├── deployment.yaml     ✓ (updated)"
echo "    ├── service.yaml        ✓ (updated)"
echo "    ├── configmap.yaml      ✓ (updated)"
echo "    └── secret.yaml         ✓ (unchanged)"
echo ""
echo "  k8s/crm-frontend/"
echo "    ├── deployment.yaml     ✓ (updated)"
echo "    └── service.yaml        ✓ (updated)"
echo ""
echo "  k8s/crm-mysql/"
echo "    ├── deployment.yaml     ✓ (updated)"
echo "    ├── service.yaml        ✓ (unchanged)"
echo "    ├── secret.yaml         ✓ (unchanged)"
echo "    └── pvc.yaml            ✓ (unchanged)"
echo ""
echo "  Root directory:"
echo "    ├── build-images.sh     ✓"
echo "    ├── deploy-k8s.sh       ✓"
echo "    └── KUBERNETES-DEPLOYMENT-GUIDE.md ✓"
echo ""
echo "Next steps:"
echo "  1. Review the changes: git diff k8s/"
echo "  2. Build images: ./build-images.sh"
echo "  3. Deploy to K8s: ./deploy-k8s.sh"
echo ""
echo "Or follow the complete guide in KUBERNETES-DEPLOYMENT-GUIDE.md"
