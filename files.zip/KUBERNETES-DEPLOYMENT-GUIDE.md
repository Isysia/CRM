# 🚀 KUBERNETES DEPLOYMENT GUIDE - CRM SYSTEM

## 📋 WYMAGANIA WSTĘPNE

### 1. Zainstalowane narzędzia:
```bash
# Sprawdź wersje
kubectl version --client
docker --version
minikube version  # lub kind/k3s
```

### 2. Uruchomiony klaster Kubernetes:
```bash
# Dla Minikube
minikube start --driver=docker --cpus=4 --memory=8192

# Sprawdź status
kubectl cluster-info
kubectl get nodes
```

---

## 🏗️ KROK 1: BUDOWANIE OBRAZÓW DOCKER

### Backend (Spring Boot)
```bash
# Z głównego katalogu projektu
docker build -t crm-app:latest -f Dockerfile .

# Weryfikacja
docker images | grep crm-app
```

### Frontend (React + Nginx)
```bash
# Skopiuj pliki konfiguracyjne do katalogu frontend
cp frontend-Dockerfile frontend/Dockerfile
cp nginx.conf frontend/nginx.conf
cp frontend.env frontend/.env

# Zbuduj obraz (z głównego katalogu projektu!)
docker build -t crm-frontend:latest -f frontend/Dockerfile .

# Weryfikacja
docker images | grep crm-frontend
```

### ⚠️ WAŻNE dla Minikube/Kind:
```bash
# Dla Minikube - załaduj obrazy do klastra
minikube image load crm-app:latest
minikube image load crm-frontend:latest

# Weryfikacja
minikube image ls | grep crm
```

---

## 🗂️ KROK 2: PRZYGOTOWANIE STRUKTURY K8S

Skopiuj zaktualizowane pliki YAML do katalogów:

```bash
# Backend
cp k8s-backend-deployment.yaml k8s/crm-app/deployment.yaml
cp k8s-backend-service.yaml k8s/crm-app/service.yaml

# Frontend  
cp k8s-frontend-deployment.yaml k8s/crm-frontend/deployment.yaml
cp k8s-frontend-service.yaml k8s/crm-frontend/service.yaml

# Database
cp k8s-database-deployment.yaml k8s/crm-mysql/deployment.yaml
```

---

## 🚀 KROK 3: DEPLOYMENT DO KUBERNETES

### 3.1 Utworzenie Namespace
```bash
kubectl apply -f k8s/namespace.yaml

# Weryfikacja
kubectl get namespaces
```

### 3.2 Deployment bazy danych (PIERWSZY!)
```bash
# Secrets
kubectl apply -f k8s/crm-mysql/secret.yaml

# PersistentVolumeClaim
kubectl apply -f k8s/crm-mysql/pvc.yaml

# Deployment
kubectl apply -f k8s/crm-mysql/deployment.yaml

# Service
kubectl apply -f k8s/crm-mysql/service.yaml

# Sprawdź status
kubectl get pods -n crm -l app=mysql
kubectl logs -n crm -l app=mysql --tail=50

# Poczekaj aż pod będzie READY (może zająć 30-60 sekund)
kubectl wait --for=condition=ready pod -l app=mysql -n crm --timeout=120s
```

### 3.3 Deployment backendu (DRUGI!)
```bash
# ConfigMap i Secret
kubectl apply -f k8s/crm-app/configmap.yaml
kubectl apply -f k8s/crm-app/secret.yaml

# Deployment
kubectl apply -f k8s/crm-app/deployment.yaml

# Service
kubectl apply -f k8s/crm-app/service.yaml

# Sprawdź status
kubectl get pods -n crm -l app=crm-app
kubectl logs -n crm -l app=crm-app --tail=100

# Poczekaj aż pod będzie READY (może zająć 2-3 minuty!)
kubectl wait --for=condition=ready pod -l app=crm-app -n crm --timeout=300s
```

### 3.4 Deployment frontendu (TRZECI!)
```bash
# Deployment
kubectl apply -f k8s/crm-frontend/deployment.yaml

# Service
kubectl apply -f k8s/crm-frontend/service.yaml

# Sprawdź status
kubectl get pods -n crm -l app=crm-frontend
kubectl logs -n crm -l app=crm-frontend --tail=50

# Poczekaj aż pod będzie READY
kubectl wait --for=condition=ready pod -l app=crm-frontend -n crm --timeout=60s
```

---

## 🔍 KROK 4: WERYFIKACJA DEPLOYMENTU

### 4.1 Sprawdź wszystkie zasoby
```bash
# Wszystkie pody w namespace crm
kubectl get all -n crm

# Szczegóły podów
kubectl get pods -n crm -o wide

# Sprawdź logi każdego komponentu
kubectl logs -n crm -l app=mysql --tail=20
kubectl logs -n crm -l app=crm-app --tail=20
kubectl logs -n crm -l app=crm-frontend --tail=20
```

### 4.2 Sprawdź services
```bash
kubectl get svc -n crm

# Powinieneś zobaczyć:
# NAME           TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)          AGE
# crm-app        ClusterIP   10.96.x.x        <none>        8080/TCP         Xm
# crm-frontend   NodePort    10.96.x.x        <none>        80:30080/TCP     Xm
# mysql          ClusterIP   10.96.x.x        <none>        3306/TCP         Xm
```

### 4.3 Sprawdź ConfigMaps i Secrets
```bash
kubectl get configmaps -n crm
kubectl get secrets -n crm
```

---

## 🌐 KROK 5: DOSTĘP DO APLIKACJI

### Dla Minikube:
```bash
# Pobierz URL do frontendu
minikube service crm-frontend -n crm --url

# Lub otwórz w przeglądarce automatycznie
minikube service crm-frontend -n crm
```

### Dla innych klastrów:
```bash
# Znajdź IP węzła
kubectl get nodes -o wide

# Frontend dostępny na: http://<NODE-IP>:30080
# Przykład: http://192.168.49.2:30080
```

### Port Forwarding (alternatywa):
```bash
# Frontend
kubectl port-forward -n crm svc/crm-frontend 3000:80

# Backend (do testowania API bezpośrednio)
kubectl port-forward -n crm svc/crm-app 8080:8080

# Baza danych (do podłączenia np. przez DBeaver)
kubectl port-forward -n crm svc/mysql 3306:3306
```

---

## 🧪 KROK 6: TESTOWANIE APLIKACJI

### 6.1 Sprawdź health endpointy
```bash
# Backend health (przez port-forward lub wewnątrz poda)
kubectl exec -n crm -it $(kubectl get pod -n crm -l app=crm-app -o jsonpath='{.items[0].metadata.name}') -- \
  wget -qO- http://localhost:8081/actuator/health

# Frontend health
kubectl exec -n crm -it $(kubectl get pod -n crm -l app=crm-frontend -o jsonpath='{.items[0].metadata.name}') -- \
  wget -qO- http://localhost:80/health
```

### 6.2 Sprawdź połączenie backend → database
```bash
kubectl logs -n crm -l app=crm-app | grep -i "liquibase"
kubectl logs -n crm -l app=crm-app | grep -i "started"
```

### 6.3 Testuj funkcjonalności w przeglądarce
1. Otwórz aplikację (URL z kroku 5)
2. Zaloguj się (domyślne konto powinno być utworzone przez Liquibase)
3. Sprawdź każdy moduł: Customers, Offers, Tasks

---

## 📊 KROK 7: MONITORING I DEBUGGING

### Przydatne komendy:
```bash
# Obserwuj pody w czasie rzeczywistym
kubectl get pods -n crm -w

# Szczegółowe informacje o podzie
kubectl describe pod -n crm <POD-NAME>

# Logi z konkretnego poda
kubectl logs -n crm <POD-NAME> -f

# Logi z poprzedniej instancji poda (jeśli się restartował)
kubectl logs -n crm <POD-NAME> --previous

# Wejdź do poda (debugging)
kubectl exec -n crm -it <POD-NAME> -- /bin/sh

# Sprawdź wydarzenia w namespace
kubectl get events -n crm --sort-by='.lastTimestamp'

# Sprawdź resource usage
kubectl top pods -n crm
kubectl top nodes
```

### Sprawdź connectivity między podami:
```bash
# Z poda backendu do bazy danych
kubectl exec -n crm -it $(kubectl get pod -n crm -l app=crm-app -o jsonpath='{.items[0].metadata.name}') -- \
  sh -c 'wget -qO- --timeout=3 http://mysql:3306 || echo "DB reachable"'

# Z poda frontendu do backendu
kubectl exec -n crm -it $(kubectl get pod -n crm -l app=crm-frontend -o jsonpath='{.items[0].metadata.name}') -- \
  wget -qO- --timeout=3 http://crm-app:8080/actuator/health
```

---

## 🔄 KROK 8: AKTUALIZACJA APLIKACJI

### Po zmianach w kodzie:
```bash
# 1. Przebuduj obraz
docker build -t crm-app:latest -f Dockerfile .
# lub
docker build -t crm-frontend:latest -f frontend/Dockerfile .

# 2. Załaduj do Minikube (jeśli używasz)
minikube image load crm-app:latest
# lub
minikube image load crm-frontend:latest

# 3. Restartuj deployment
kubectl rollout restart deployment/crm-app -n crm
# lub
kubectl rollout restart deployment/crm-frontend -n crm

# 4. Obserwuj rollout
kubectl rollout status deployment/crm-app -n crm
```

---

## 🧹 KROK 9: CZYSZCZENIE

### Usuń całą aplikację:
```bash
# Usuń wszystko z namespace
kubectl delete namespace crm

# Lub usuń poszczególne komponenty
kubectl delete -f k8s/crm-frontend/
kubectl delete -f k8s/crm-app/
kubectl delete -f k8s/crm-mysql/
kubectl delete -f k8s/namespace.yaml
```

### Zatrzymaj Minikube:
```bash
minikube stop
# lub usuń klaster całkowicie
minikube delete
```

---

## ⚠️ TYPOWE PROBLEMY I ROZWIĄZANIA

### 1. Pod się nie startuje (ImagePullBackOff)
```bash
# Sprawdź czy obraz istnieje
minikube image ls | grep crm

# Załaduj ponownie
minikube image load crm-app:latest
```

### 2. Backend nie może połączyć się z bazą
```bash
# Sprawdź logi bazy danych
kubectl logs -n crm -l app=mysql --tail=100

# Sprawdź czy secret ma poprawne dane
kubectl get secret mysql-secret -n crm -o yaml
```

### 3. Frontend nie widzi backendu
```bash
# Sprawdź nginx config
kubectl exec -n crm -l app=crm-frontend -- cat /etc/nginx/conf.d/default.conf

# Sprawdź czy backend service istnieje
kubectl get svc crm-app -n crm
```

### 4. Brak miejsca w PersistentVolume
```bash
# Sprawdź PVC status
kubectl get pvc -n crm

# Zwiększ rozmiar w pvc.yaml i apply ponownie
kubectl apply -f k8s/crm-mysql/pvc.yaml
```

---

## 📚 DODATKOWE ZASOBY

### Sprawdź aktualny stan klastra:
```bash
# Dashboard Kubernetes (Minikube)
minikube dashboard

# Lub z kubectl proxy
kubectl proxy
# Otwórz: http://localhost:8001/api/v1/namespaces/kubernetes-dashboard/services/https:kubernetes-dashboard:/proxy/
```

### Eksportuj konfigurację (backup):
```bash
# Zapisz wszystkie zasoby do plików
kubectl get all -n crm -o yaml > crm-backup.yaml
kubectl get configmaps -n crm -o yaml > crm-configmaps.yaml
kubectl get secrets -n crm -o yaml > crm-secrets.yaml
```

---

## ✅ CHECKLIST DLA DYPLOMU

- [ ] Namespace utworzony
- [ ] Wszystkie obrazy Docker zbudowane
- [ ] Obrazy załadowane do klastra
- [ ] PersistentVolumeClaim utworzony dla bazy danych
- [ ] Secrets i ConfigMaps utworzone
- [ ] Baza danych działa (1/1 Ready)
- [ ] Backend działa (2/2 Ready) z Liquibase migrations
- [ ] Frontend działa (2/2 Ready)
- [ ] Aplikacja dostępna przez przeglądarkę
- [ ] Login działa
- [ ] CRUD operacje działają dla wszystkich modułów
- [ ] Screenshoty z `kubectl get all -n crm`
- [ ] Screenshoty z działającej aplikacji
- [ ] Logi zapisane jako dowód działania

---

## 🎓 DOKUMENTACJA DLA PRACY DYPLOMOWEJ

### Sekcja "Deployment Architecture":
```
System CRM został wdrożony w środowisku Kubernetes z następującą architekturą:

1. **Database Tier** - MariaDB 11.2 z persistent storage (5GB PVC)
2. **Application Tier** - Spring Boot backend (2 replicas) z Liquibase migrations
3. **Presentation Tier** - React SPA z Nginx reverse proxy (2 replicas)

Komunikacja:
- Frontend → Backend: przez Nginx proxy (http://crm-app:8080/api)
- Backend → Database: przez ClusterIP service (mysql:3306)
- External Access: NodePort service na porcie 30080
```

### Architektura High Availability:
- **Frontend**: 2 repliki z load balancing
- **Backend**: 2 repliki z session affinity
- **Database**: 1 replika z persistent storage (single point of write)
- **Health Checks**: liveness, readiness, i startup probes na wszystkich komponentach
- **Resource Management**: memory/CPU limits i requests dla optymalizacji

---

Powodzenia z obroną! 🎓🚀
